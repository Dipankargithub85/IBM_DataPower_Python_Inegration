"""
Created on Fri Mar  5 15:21:41 2021

@author: Dipankar das
"""

#!/usr/bin/env python3

import requests
import urllib3
import os
from config import decode
import xml.etree.ElementTree as ET    # nosec

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def getsshstatus(data,servicename,statustype,env):
    serverlist = list()
    for val in data:
        if val['Name'] == servicename:
            defaultdom = dict()
            servicedict = dict()
            tmpsrvli = list()
            dictlist = list()
            for srvval in val['servers']:
                if srvval['active'] ==True:
                    if 'private' in servicename:
                        if env == 'pro':
                            servername = getprvtsrv(srvval['name'])
                            tmpsrvli.append(servername)
                        else:
                            tmpsrvli.append(srvval['name'])
                            
                    else:
                        tmpsrvli.append(srvval['name'])
            
            
            srvdict=fetchsshstatus('default',tmpsrvli)    
            defaultdom = {'default':srvdict}
            dictlist.append(defaultdom)
        
            servicedict = {statustype:dictlist}
            serverlist.append(servicedict)
            break
    
    return serverlist

def fetchsshstatus(domain,srvli):
    srvresli=list()
    for srv in srvli:
        url = 'https://' + srv + ':5550/service/mgmt/current'
        req ='<?xml version="1.0" encoding="UTF-8"?><env:Envelope xmlns:env="http://schemas.xmlsoap.org/soap/envelope/"><env:Body><dp:request domain="default" xmlns:dp="http://www.datapower.com/schemas/management"><dp:get-status class="ObjectStatus" object-class="SSHService"/></dp:request></env:Body></env:Envelope>'
        key=''
        credential=''
        key = os.getenv('GConnect')
        #key='1234'
        credential = decode.getgdetails(key)
        headers= {'Authorization':'Basic ' + credential }
        xmlDict= dict()
        dictli=list()
        try:
            response = requests.post(url, data=req, headers=headers,verify=False)  # nosec
            data=response.content
            tree = ET.fromstring(data)

            for child in tree.iter('*'):
                opstate=''
                adstatus=''
                flag =False
                if child.tag=='ObjectStatus':
                    for val in child.iter():
                        if val.tag == 'OpState':
                            opstate= val.text
                        if val.tag == 'AdminState':
                            adstatus = val.text;
                        if val.tag =='Name':
                            flag =True
                            tempdict={'OpState':opstate,'AdminState':adstatus}
                            dictli.append(tempdict)
                       
                            break
            
                if flag:
                    xmlDict = {srv:dictli}
                    srvresli.append(xmlDict)
                    break
        except:
            print("Connection issue for the server:",srv)
 
    return srvresli


def getprvtsrv(server):
    srvli = server.split('.')
    svrfn = srvli[0] + '.wt.'+ srvli[1] + '.' + srvli[2]
    return  svrfn
