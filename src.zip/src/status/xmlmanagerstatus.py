"""
Created on Fri Feb 26 13:40:34 2021

@author: Dipankar Das
"""

#!/usr/bin/env python3

import requests
import urllib3
import os
from config import decode
import xml.etree.ElementTree as ET   # nosec

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def getxmlmanagerstatus(data,servicename,statustype,env):
    serverlist = list()
    for val in data:
        if val['Name'] == servicename:
            domaindict = dict()
            servicedict = dict()
            domainname = val['domain']
            tmpsrvli = list()
            dictlist = list()
            for srvval in val['servers']:
                if srvval['active'] ==True:
                    if 'private' in servicename:
                        
                        if env == 'pro':
                            servername = getprvtsrv(srvval['name'])
                            tmpsrvli.append(servername)
                        else:
                            tmpsrvli.append(srvval['name'])
                    else:
                        tmpsrvli.append(srvval['name'])
        

            srvdict=fetchdetails(domainname,tmpsrvli)
            domaindict = {domainname:srvdict}
            dictlist.append(domaindict)
            servicedict = {statustype:dictlist}
            serverlist.append(servicedict)
            break

    return serverlist

def fetchdetails(domain,srvli):
    srvresli=list()
    webapili= ['webapi','webapi-internal']
    for srv in srvli:
        url = 'https://' + srv + ':5550/service/mgmt/current'
        req ='<?xml version="1.0" encoding="UTF-8"?><env:Envelope xmlns:env="http://schemas.xmlsoap.org/soap/envelope/"><env:Body><dp:request domain="'+domain+'" xmlns:dp="http://www.datapower.com/schemas/management"><dp:get-status class="ObjectStatus" object-class="XMLManager"/></dp:request></env:Body></env:Envelope>'
        key=''
        credential=''
        key = os.getenv('GConnect')
        #key='1234'
        credential = decode.getgdetails(key)
        headers= {'Authorization':'Basic ' + credential }
        xmlDict= dict()
        dictli=list()
        try:
            response = requests.post(url, data=req, headers=headers,verify=False)  # nosec
  
            data=response.content
            tree = ET.fromstring(data)

            for child in tree.iter('*'):
                opstate=''
                adstatus=''
                tempdict=dict()
                if child.tag=='ObjectStatus':
                    for val in child.iter():
                        if val.tag == 'OpState':
                            opstate= val.text
                        if val.tag == 'AdminState':
                            adstatus = val.text;
                        if val.tag =='Name':
                            if val.text in webapili:
                                name=val.text
                                tempdict={'Name':name,'OpState':opstate,'AdminState':adstatus}
                                dictli.append(tempdict)
                                break

            xmlDict = {srv:dictli}
            srvresli.append(xmlDict)
        except:
            print("Connection issue for the server:",srv)
    
    return srvresli

def getprvtsrv(server):
    srvli = server.split('.')
    svrfn = srvli[0] + '.wt.'+ srvli[1] + '.' + srvli[2]
    return  svrfn
