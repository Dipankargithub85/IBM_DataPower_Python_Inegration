"""
Created on Fri Feb 26 13:40:34 2021

@author: Dipankar Das
"""

#!/usr/bin/env python3

from pymongo import MongoClient
import sys
import urllib.parse
import os
from config import decode


def getServerlist(envname):
    try:
        keytup = tuple()
        urltup = tuple()
        key =''
        url=''
        url = os.getenv('MHost')
        key = os.getenv('GConnect')
        #print(key)
        
        keytup = decode.getdbdetails(key)
        #print(keytup)
        urltup = decode.getdburl(url)
        
                 
        if envname =='dev':
            myclient = MongoClient('mongodb://' + keytup[0]  + ':' + keytup[1] + '@' +urltup[0] )
            myquery = {"environment" : "DEV", "type" : "Gateway"}
            mydb = myclient["appdb"]
            mycol = mydb["APIServerInfo"]
            data = mycol.find(myquery)
            myclient.close()
            return data
        
        if envname =='pre':
            myclient = MongoClient('mongodb://' + keytup[0]  + ':' + keytup[1] + '@' +urltup[0] )
            myquery = {"environment" : "PRE", "type" : "Gateway"}
            mydb = myclient["appdb"]
            mycol = mydb["APIServerInfo"]
            data = mycol.find(myquery)
            myclient.close()
            return data
        
        if envname =='pro':
            password = urllib.parse.quote_plus(keytup[2])
            myclient = MongoClient('mongodb://' + keytup[0]  + ':' + password + '@' +urltup[1])
            mydb = myclient["appdb"]
            mycol = mydb["APIServerInfo"]
            myquery = {"environment" : "PRO", "type" : "Gateway"}
            data = mycol.find(myquery)
            myclient.close()
            return data
       
    except:
        print("connection Error while connect with Database..Please Check with your DBA")
        sys.exit(0)
