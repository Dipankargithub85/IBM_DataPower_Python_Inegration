"""
Created on Tue Apr  6 17:06:52 2021

@author: Dipankar Das
"""
#!/usr/bin/env python3

import base64

def getdbdetails(encodeval):
    dbtup = tuple()
    base64_bytes = encodeval.encode('ascii')
    message_bytes = base64.b64decode(base64_bytes)
    message = message_bytes.decode('ascii')
    dbsplit = message.split(':')
    dbtup = (dbsplit[0],dbsplit[1],dbsplit[2])
    return dbtup
    #print (dbtup)
    #print(message)

def getgdetails(encodeval):
    
    base64_bytes = encodeval.encode('ascii')
    message_bytes = base64.b64decode(base64_bytes)
    message = message_bytes.decode('ascii')
    gsplit = message.split(':')
    return gsplit[3]
   

def getdburl(encodeval):    
    
    dbtup = tuple()    
    base64_bytes = encodeval.encode('ascii')
    message_bytes = base64.b64decode(base64_bytes)
    message = message_bytes.decode('ascii')
    dbsplit = message.split('$')
    dbtup = (dbsplit[0],dbsplit[1])
    return dbtup
