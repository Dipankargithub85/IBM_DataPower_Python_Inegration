from setuptools import setup

setup(
    name='datapower-utility',
    version='0.0.1-SNAPSHOT',
    packages=[],
    url='',
    license='',
    author='S0.0.1-SNAPSHOT97',
    author_email='S0.0.1-SNAPSHOT97@yourdomain.com',
    description='',
    install_requires=[
        'flask',
        'uwsgi'
    ]
)
