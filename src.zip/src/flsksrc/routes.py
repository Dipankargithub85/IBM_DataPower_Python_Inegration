"""
Created on Fri Apr 02 13:40:34 2021

@author: Dipankar Das
"""


#!/usr/bin/env python3

from flask import render_template,jsonify,request,flash,send_file
from flsksrc import app
from flsksrc.forms import BaseForm
from flsksrc import mainapp
import xlsxwriter


posts = [
    {
        'title': 'DataPower-Health-Check-Utility',
        'content': 'Server Status and Configuration details along with crypto details',
    }
]


@app.route("/getdetails", methods=['GET', 'POST'])
def getdetails():
    
    form = BaseForm()
    srvclist= list()
    srvlist = list()
    fnldict = dict()
    counttup= tuple()
    if request.method =='POST':
    #if form.validate_on_submit():
         if  request.form.get('srvcnm') and request.form.get('srvnm'):
             srvclist= mainapp.getserveiceDetails(request.form.get('env'))
             srvlist = mainapp.getserverdetails(request.form.get('srvcnm'),request.form.get('env'))
             srvclist.insert(0,'Select')
             srvlist.insert(0,'Select')
             form.srvcnm.choices = srvclist
             form.srvnm.choices = srvlist
             flagvalidate =False
             
             
             
             if request.form.get('env') == 'sel':
                 flash('Please select the proper value of Environment','danger')
                 flagvalidate= True
                 return render_template('getdetails.html',form=form)
             if request.form.get('typ') == 'sel1':
                 flash('Please select the proper value of Type','danger')
                 flagvalidate= True
                 return render_template('getdetails.html',form=form)
             if request.form.get('srvcnm') == 'Select':
                 flash('Please select the proper value of Service-Name','danger')
                 flagvalidate= True
                 return render_template('getdetails.html',form=form)
             if request.form.get('srvnm') == 'Select':
                 flash('Please select the proper value of Server-Name','danger')
                 flagvalidate= True
                 return render_template('getdetails.html',form=form)
             
             if not flagvalidate:
                
                 if request.form.get('env') == 'pro':
                    if 'private' in request.form.get('srvcnm'):
                        srvname= getprvtsrv(request.form.get('srvnm'))
                 else:
                    srvname= request.form.get('srvnm')
                 
                 if form.typ.data =='stat':
                     fnldict =  mainapp.getstatdetails(request.form.get('srvcnm'),request.form.get('env'))
                     return render_template('viewstat.html',form=form,statusdetails=fnldict,legend='DataPower Server Status Details',servername=srvname)
                     
                     
                 if form.typ.data =='config':
                     fnldict =  mainapp.getconfigdetails(request.form.get('srvcnm'),request.form.get('env'))
                     return render_template('viewconfig.html',form=form,configdetails=fnldict,legend='DataPower Server Configuration Details',servername=srvname)
                 
                 if form.typ.data =='cryptcert':
                     fnldict =  mainapp.getcryptocertdetails(request.form.get('srvcnm'),request.form.get('env'))
                     counttup=getcount(fnldict,srvname)
                     return render_template('viewcrypto.html',form=form,cryptodetails=fnldict,legend='DataPower Crypto Cert Details',servername=srvname,servicenm=request.form.get('srvcnm'),envnm=request.form.get('env'),typnm ='cryptcert',cmccnt=counttup[0],othcnt=counttup[1],cryptoheader="Crypto-Certificate-Name")   
                 
                 if form.typ.data =='cryptkey':
                     fnldict =  mainapp.getcryptokeydetails(request.form.get('srvcnm'),request.form.get('env'))
                     counttup=getcount(fnldict,srvname)
                     return render_template('viewcrypto.html',form=form,cryptodetails=fnldict,legend='DataPower Server Crypto Key Details',servername=srvname,servicenm=request.form.get('srvcnm'),envnm=request.form.get('env'),typnm ='cryptkey',cmccnt=counttup[0],othcnt=counttup[1],cryptoheader="Crypto-Key-Name")


    return render_template('getdetails.html', posts=posts,form=form)  
   

@app.route("/envnm/<envname>")
def getservice(envname):
    servicli = list()
    servicli=mainapp.getserveiceDetails(envname)
    #print('servicli:',servicli)
    return jsonify({'serviceli':servicli})


@app.route("/servli/<servcval>/<env>")
def getserver(servcval,env):
    serverli = list()
    serverli=mainapp.getserverdetails(servcval,env)
    return jsonify({'serverli':serverli})

@app.route("/download/<servername>/<servicenm>/<envnm>/<typnm>",methods=['GET'])
def download(servername,servicenm,envnm,typnm):
    
    if request.method =='GET':
              
        if typnm =='cryptcert':
            
            fnldict =  mainapp.getcryptocertdetails(servicenm,envnm)
            preparedexcl(fnldict,'cryptcert',servername)
            return send_file('cryptoCertDetails.xlsx', as_attachment=True)
        
        if typnm =='cryptkey':
           fnldict =  mainapp.getcryptokeydetails(servicenm,envnm)
           preparedexcl(fnldict,'cryptkey',servername)
           return send_file('cryptoKeyDetails.xlsx', as_attachment=True)
       
 
 

def getcount(obj,servname):
    cnttup=tuple()
    cmccnt = 0  
    othcnt = 0
    for key,val in obj.items():
        for li in val:
             for lii in li:
                for key1,valu in lii.items():
                    for value in valu:
                       for key2,val2 in value.items():
                             for val3 in val2:
                                 
                            
                                 for key3,val4 in val3.items():
                                     if servname ==  key3:
                                         for vali in val4:
                                             if 'cmc' in vali:
                                                 cmccnt = cmccnt + 1
                                                 
                                             else:
                                                 othcnt = othcnt + 1
                                           
                                          
    
    
    
   
    cnttup = (cmccnt,othcnt)
    return cnttup
    
    
def getprvtsrv(server):
    srvli = server.split('.')
    svrfn = srvli[0] + '.wt.'+ srvli[1] + '.' + srvli[2]
    return  svrfn
    
   
def preparedexcl(obj,typval,srvname):
    
    if typval == 'cryptcert':
        workbook = xlsxwriter.Workbook('flsksrc/cryptoCertDetails.xlsx')
        worksheet = workbook.add_worksheet('cryptoCertDetails')
        
    if typval == 'cryptkey' :
        workbook = xlsxwriter.Workbook('flsksrc/cryptoKeyDetails.xlsx')
        worksheet = workbook.add_worksheet('cryptoCertDetails')
    
   
    cell_format = workbook.add_format()
    cell_format.set_border()
    row=0
    col=0    
    worksheet.set_column(0,2,70)
    for key,val in obj.items():
        
        worksheet.write(row, col, "Service-Name",cell_format)
        worksheet.write(row, col+1, key,cell_format)
        for li in val:
             for lii in li:
                for key1,valu in lii.items():
                    worksheet.write(row + 1, col, "Status-Type",cell_format)
                    worksheet.write(row + 1, col+1, key1,cell_format)
                    for value in valu:
                       for key2,val2 in value.items():
                           worksheet.write(row + 2, col, "Domain-name",cell_format)
                           worksheet.write(row + 2, col+1, key2,cell_format)
                           for val3 in val2:
                               for key3,val4 in val3.items():
                                   if srvname ==  key3:
                                       worksheet.write(row + 3, col, "serverName",cell_format)
                                       worksheet.write(row + 3, col+1, key3,cell_format)
                                       worksheet.write(row + 4, col, "Total-Count",cell_format)
                                       worksheet.write(row + 4, col+1, len(val4),cell_format)
                                       if typval == 'cryptcert':
                                           worksheet.write(row + 5, col, 'Crypto-Certificate-Name',cell_format)
                                       else:
                                           worksheet.write(row + 5, col, 'Crypto-Key-Name',cell_format)  
                                       
                                       newrow = row + 5
                                       i = 1
                                       for vali in val4:
                                           
                                           worksheet.write(newrow + i, col, vali,cell_format)
                                           i=i+1
                                              
    
    workbook.close()
    
    
    

        
