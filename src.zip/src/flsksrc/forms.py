"""
Created on Fri Apr 02 13:40:34 2021

@author: Dipankar Das
"""

#!/usr/bin/env python3

from flask_wtf import FlaskForm
from wtforms import SelectField,SubmitField
from wtforms.validators import DataRequired


class BaseForm(FlaskForm):
    env = SelectField('Environment',choices=[('sel','Select'),('dev','DEV'),('pre','PRE'),('pro','PRO')],validators=[DataRequired()])
    typ = SelectField('Type',choices=[('sel1','Select'),('stat','Status'),('config','Configuration'),('cryptcert','CryptoCert'),('cryptkey','CryptoKey')],validators=[DataRequired()])
    srvcnm = SelectField('Service-Name',choices=[],validators=[DataRequired()])
    srvnm = SelectField('Server-Name',choices=[],validators=[DataRequired()])
    submit = SubmitField('Get-Details')