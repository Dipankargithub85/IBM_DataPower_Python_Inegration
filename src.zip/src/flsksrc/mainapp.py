"""
Created on Fri Apr 02 13:40:34 2021

@author: Dipankar Das
"""

#!/usr/bin/env python3

from dbconnection import dbconn
from status import domainstat,ntpstat,ethernetinterface,sshstatus,xmlmanagerstatus,quotastatus
from confsetting import jsonsetting,loadbalancerfreq,multiprotocolsetting,patchinfo,cryptocert,cryptokey
from wtforms.validators import ValidationError

def getstatdetails(servicename,envname):
    
    try:
        obj = dbconn.getServerlist(envname)
        data= list(obj)
        finaldict= dict()
        objli = list()
                   
        domainobj   = domainstat.getdomainstatusdetails(data,servicename,'Domain-Status',envname)
        objli.append(domainobj)
        NtpstatObj = ntpstat.getNTPStatusdetails(data,servicename,'NTP-Status',envname)
        objli.append(NtpstatObj)
        ethobj=ethernetinterface.getethernetinerface(data,servicename,'EthernetInterface-Status',envname)
        objli.append(ethobj)
        sshobj=sshstatus.getsshstatus(data,servicename,'SSHService-Status',envname)
        objli.append(sshobj)
        xmlobj=xmlmanagerstatus.getxmlmanagerstatus(data,servicename,'XMLManager-Status/MultiProtocolGateway-Status',envname)
        objli.append(xmlobj)
        quotaobj=quotastatus.getquotastatus(data,servicename,'QuotaEnforcementServer-Status',envname)
        objli.append(quotaobj)
        
        if len(objli) == 0:
            raise ValidationError("Someting Went Wrong in SOMA Call.. ")
           
            
        finaldict= {servicename:objli}
        return finaldict
    
    except:
        raise ValidationError("connection Error while connect with Database..Please Check with your DBA")

    
        
        
def getconfigdetails(servicename,envname):
    
     try:
         
         obj = dbconn.getServerlist(envname)
         data= list(obj)
         finaldict= dict()
         objli = list()
       
         jsonobj   = jsonsetting.getjsoninfo(data,servicename,'JSONSetting',envname)
         objli.append(jsonobj)
         loadbalObj = loadbalancerfreq.getfreqinfo(data,servicename,'analytics-lb',envname)
         objli.append(loadbalObj)
         multiobj=multiprotocolsetting.getbackpersistentimeout(data,servicename,'BackPersistentTimeoutValue',envname)
         objli.append(multiobj)
         patchobj=patchinfo.getpathinfo(data,servicename,'PatchInfo',envname)
         objli.append(patchobj)
        
         if len(objli) == 0:
            raise ValidationError("Someting Went Wrong in SOMA Call.. ")
                     
         finaldict= {servicename:objli}
             
        
         return finaldict
    
     except:
         raise ValidationError("connection Error while connect with Database..Please Check with your DBA")

        
 
        
     
def getcryptocertdetails(servicename,envname):
    
    try :
        obj = dbconn.getServerlist(envname)
        data= list(obj)
        finaldict= dict()
        objli = list()
        cryptocertobj   = cryptocert.getcryptocert(data,servicename,'CryptoCertificate',envname)
        objli.append(cryptocertobj)
        if len(objli) == 0:
            raise ValidationError("Someting Went Wrong in SOMA Call.. ")
        finaldict= {servicename:objli}
    
        return finaldict
    
    except:
         raise ValidationError("connection Error while connect with Database..Please Check with your DBA")
        
  

def getcryptokeydetails(servicename,envname):
    
    try :
        obj = dbconn.getServerlist(envname)
        data= list(obj)
        finaldict= dict()
        objli = list()
        cryptokeyobj = cryptokey.getcryptoKey(data,servicename,'CryptoKey',envname)
        objli.append(cryptokeyobj)
        if len(objli) == 0:
            raise ValidationError("Someting Went Wrong in SOMA Call.. ")
        finaldict= {servicename:objli}
    
        return finaldict
    
    except:
         raise ValidationError("connection Error while connect with Database..Please Check with your DBA")
                
        
 
        
        

   
def getserveiceDetails(env):
    
    try:
        obj = dbconn.getServerlist(env)
        data= list(obj)
        #print('data',data)
        servicelist = list()
        for val in data:
            servicelist.append(val['Name'])
   
        return servicelist
        
    except:
        raise ValidationError("connection Error while connect with Database..Please Check with your DBA")
        
    

def getserverdetails(servcval,envname):
    
           
    try:
        obj = dbconn.getServerlist(envname)
        data= list(obj)
        serverlist = list()
        for val in data:
            if val['Name'] == servcval:
                for srvval in val['servers']:
                    if srvval['active'] ==True:
                        serverlist.append(srvval['name'])
    
        return serverlist
        
    except:
        raise ValidationError("connection Error while connect with Database..Please Check with your DBA")
        
