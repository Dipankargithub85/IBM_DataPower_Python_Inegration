"""
Created on Fri Apr 02 13:40:34 2021

@author: Dipankar Das
"""

#!/usr/bin/env python3

from flask import Flask

app = Flask(__name__)
app.config['SECRET_KEY'] = '5791628bb0b13ce0c676dfde21234565'  # nosec
from flsksrc import routes
from flsksrc.handlers import errors
app.register_blueprint(errors)
