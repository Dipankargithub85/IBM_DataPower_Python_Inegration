"""
Created on Thu Mar  4 13:15:14 2021

@author: Dipankar das
"""

#!/usr/bin/env python3

import requests
import urllib3
import os
from config import decode
import xml.etree.ElementTree as ET   # nosec

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def getjsoninfo(data,serviceName,statustype,env):
    serverlist = list()
    for val in data:
        
        if val['Name'] == serviceName:
            domaindict = dict()
            servicedict = dict()
            domainname = val['domain']
            tmpsrvli = list()
            dictlist = list()
            for srvval in val['servers']:
                if srvval['active'] ==True:
                    if 'private' in serviceName:
                        if env =='pro':
                            servername = getprvtsrv(srvval['name'])
                            tmpsrvli.append(servername)
                        else:
                            tmpsrvli.append(srvval['name'])
                    else:
                        tmpsrvli.append(srvval['name'])
        
            srvdict=fetchjsoninfo(domainname,tmpsrvli)
            domaindict = {domainname:srvdict}
            dictlist.append(domaindict)
            servicedict = {statustype:dictlist}
            serverlist.append(servicedict)
            break
    
    return serverlist

def fetchjsoninfo(domain,srvli):
    srvresli=list()
    for srv in srvli:
        url = 'https://' + srv + ':5550/service/mgmt/current'
        req='<?xml version="1.0" encoding="UTF-8"?><env:Envelope xmlns:env="http://schemas.xmlsoap.org/soap/envelope/"><env:Body><dp:request domain="' +domain +'" xmlns:dp="http://www.datapower.com/schemas/management"><dp:get-config class="JSONSettings"/></dp:request></env:Body></env:Envelope>'
        key=''
        credential=''
        key = os.getenv('GConnect')
        #key='1234'
        credential = decode.getgdetails(key)
        headers= {'Authorization':'Basic ' + credential }
        xmlDict= dict()
        dictli= list()
        try:
            response = requests.post(url, data=req, headers=headers,verify=False)  # nosec
  
            data=response.content
            tree = ET.fromstring(data)

            for child in tree.iter('*'):
                tempdict = dict()
                 
                if child.tag == 'JSONMaxValueLength':
                    maxval= child.text
                    tempdict ={'JSONMaxValueLength_Existing_Value':maxval,'JSONMaxValueLength_Desire_Value':'256000'}
                    dictli.append(tempdict)
                    break
                
            xmlDict = {srv:dictli}
          
            srvresli.append(xmlDict)   
        except:
            print("Connection issue for the server:",srv)
            
    return srvresli

def getprvtsrv(server):
    srvli = server.split('.')
    svrfn = srvli[0] + '.wt.'+ srvli[1] + '.' + srvli[2]
    return  svrfn
